# MindLevel - Gamificação Acadêmica

Plataforma de gamificação acadêmica focada em transformar o estudo em uma jornada de progresso e recompensas.

## 🚀 Tecnologias

- **Frontend**: React 18, Vite, Tailwind CSS, Motion
- **Backend (API)**: Node.js (Express)
- **Banco de Dados & Autenticação**: Supabase
- **Estilização**: Design System Brutalista/Tecnológico

## 🛠️ Configuração

1. Clone o repositório
2. Instale as dependências: `npm install`
3. Configure as variáveis de ambiente no arquivo `.env`:
   ```env
   VITE_SUPABASE_URL=seu-projeto.supabase.co
   VITE_SUPABASE_ANON_KEY=sua-chave-anon
   ```
4. Inicie o servidor: `npm run dev`

## 📦 Estrutura do Projeto

- `/src`: Código fonte do frontend
- `/server.ts`: Backend Node.js
- `/supabase`: Migrações do banco de dados

## 🛡️ Licença

Este projeto é de uso exclusivo para fins acadêmicos e demonstrativos.
