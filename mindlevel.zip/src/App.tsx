import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, useNavigate, Navigate } from 'react-router-dom';
import { Sidebar } from './components/Sidebar';
import { TopNav } from './components/TopNav';
import { Dashboard } from './components/Dashboard';
import { QuizView } from './components/QuizView';
import { ResultsView } from './components/ResultsView';
import { Leaderboard } from './components/Leaderboard';
import { AchievementsPage } from './components/AchievementsPage';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { Login } from './components/auth/Login';
import { Register } from './components/auth/Register';
import { Loader2, AlertTriangle, RefreshCw } from 'lucide-react';
import { useParams } from 'react-router-dom';

class ErrorBoundary extends React.Component<{ children: React.ReactNode }, { hasError: boolean, error: any }> {
  constructor(props: any) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: any) {
    return { hasError: true, error };
  }

  componentDidCatch(error: any, errorInfo: any) {
    console.error("ERRO CRÍTICO ENCONTRADO:", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-surface flex flex-col items-center justify-center p-6 text-center">
          <div className="technical-card rounded-lg p-10 max-w-md border-error/50">
            <AlertTriangle className="text-error w-12 h-12 mx-auto mb-4" />
            <h1 className="text-xl font-bold text-on-surface mb-2 uppercase tracking-tight">Falha Crítica no Sistema</h1>
            <p className="text-sm text-on-surface-variant font-mono mb-6 bg-black/20 p-4 rounded text-left overflow-auto max-h-40">
              {this.state.error?.message || "Erro desconhecido durante a inicialização."}
            </p>
            <button 
              onClick={() => window.location.reload()}
              className="flex items-center justify-center gap-2 w-full bg-primary text-on-primary font-bold py-3 rounded text-[11px] uppercase tracking-widest"
            >
              <RefreshCw size={14} /> Reiniciar Sistema
            </button>
            <p className="mt-6 text-[9px] text-on-surface-variant/50 uppercase tracking-widest">
              Dica: Verifique as Variáveis de Ambiente no Vercel.
            </p>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { user, loading, logout } = useAuth();
  const [showDiagnostic, setShowDiagnostic] = useState(false);
  const navigate = useNavigate();

  React.useEffect(() => {
    let timeout: any;
    if (loading) {
      timeout = setTimeout(() => setShowDiagnostic(true), 6000);
    }
    return () => clearTimeout(timeout);
  }, [loading]);

  const handleForceLogout = async () => {
    await logout();
    navigate('/login');
    window.location.reload();
  };

  if (loading) {
    return (
      <div key="auth-loader" className="min-h-screen bg-[#050505] flex flex-col items-center justify-center gap-6 p-6">
        <div className="relative">
          <Loader2 className="animate-spin text-emerald-500 w-12 h-12" />
          <div className="absolute inset-0 border border-emerald-500/20 rounded-full animate-pulse" />
        </div>
        <div className="text-center space-y-4 max-w-xs">
          <p className="font-mono text-[10px] uppercase tracking-[0.4em] text-emerald-500/60">Sincronizando Sistema...</p>
          
          {showDiagnostic && (
            <motion.div 
              initial={{ opacity: 0 }} 
              animate={{ opacity: 1 }}
              className="space-y-4 pt-4 border-t border-white/5"
            >
              <p className="text-[9px] text-on-surface-variant uppercase tracking-widest leading-relaxed">
                A conexão com o servidor está demorando. 
                Se você deseja trocar de conta ou reiniciar a sessão:
              </p>
              <div className="flex flex-col gap-2">
                <button 
                  onClick={() => window.location.reload()}
                  className="w-full bg-white/5 border border-outline py-2 rounded text-[9px] font-bold uppercase tracking-widest text-on-surface hover:bg-white/10"
                >
                  Recarregar
                </button>
                <button 
                  onClick={handleForceLogout}
                  className="w-full border border-error/30 py-2 rounded text-[9px] font-bold uppercase tracking-widest text-error hover:bg-error/10"
                >
                  Encerrar Sessão (Logout)
                </button>
              </div>
            </motion.div>
          )}
        </div>
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/login" />;
  }

  return <>{children}</>;
}

function MainLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-screen bg-surface">
      <Sidebar />
      <div className="flex-1 flex flex-col min-w-0">
        <TopNav />
        <main className="flex-1 p-6 md:p-10 max-w-7xl mx-auto w-full">
          {children}
        </main>
      </div>
    </div>
  );
}

function HomePage() {
  return <Dashboard />;
}

function QuizPage() {
  const [showResults, setShowResults] = useState(false);
  const [score, setScore] = useState(0);
  const [totalQuestions, setTotalQuestions] = useState(0);
  const navigate = useNavigate();
  const { subjectId } = useParams();
  const { updateUserStats } = useAuth();

  const handleComplete = (finalScore: number) => {
    setScore(finalScore);
    // Award 250 XP per correct answer + 500 bonus if 100%
    const xpGain = (finalScore * 250) + (finalScore === totalQuestions && totalQuestions > 0 ? 500 : 0);
    updateUserStats(xpGain);
    setShowResults(true);
  };

  if (showResults) {
    return <ResultsView score={score} totalQuestions={totalQuestions} onReset={() => navigate('/')} />;
  }

  return <QuizView onComplete={handleComplete} subjectId={subjectId} onQuestionsLoad={(count) => setTotalQuestions(count)} />;
}

export default function App() {
  return (
    <ErrorBoundary>
      <AuthProvider>
      <Router>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          
          <Route path="/" element={
            <ProtectedRoute>
              <MainLayout>
                <HomePage />
              </MainLayout>
            </ProtectedRoute>
          } />

          <Route path="/leaderboard" element={
            <ProtectedRoute>
              <MainLayout>
                <Leaderboard />
              </MainLayout>
            </ProtectedRoute>
          } />

          <Route path="/achievements" element={
            <ProtectedRoute>
              <MainLayout>
                <AchievementsPage />
              </MainLayout>
            </ProtectedRoute>
          } />
          
          <Route path="/subjects" element={
            <ProtectedRoute>
              <MainLayout>
                <div className="flex flex-col items-center justify-center p-20 text-center space-y-6">
                  <div className="w-16 h-16 border border-outline rounded flex items-center justify-center text-on-surface-variant mb-4">
                     <Loader2 size={32} className="opacity-20" />
                  </div>
                  <h1 className="text-2xl font-light uppercase tracking-widest text-on-surface">Catálogo de <span className="font-bold">Módulos</span></h1>
                  <p className="text-[10px] uppercase tracking-[0.2em] text-on-surface-variant max-w-sm leading-relaxed">Status: Em desenvolvimento. Acesso restrito a usuários Alpha.</p>
                  <button 
                    onClick={() => window.location.href = '/'}
                    className="bg-white/5 border border-outline text-on-surface px-8 py-3 rounded text-[10px] uppercase tracking-widest font-bold hover:bg-white/10 transition-colors"
                  >
                    Retornar ao Hub
                  </button>
                </div>
              </MainLayout>
            </ProtectedRoute>
          } />
          
          <Route path="/quiz" element={
            <ProtectedRoute>
              <QuizPage />
            </ProtectedRoute>
          } />

          <Route path="/quiz/:subjectId" element={
            <ProtectedRoute>
              <QuizPage />
            </ProtectedRoute>
          } />

          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </Router>
    </AuthProvider>
    </ErrorBoundary>
  );
}
