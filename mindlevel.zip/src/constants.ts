import { Subject, UserStats, Achievement, Question } from './types';

export const SUBJECTS: Subject[] = [
  {
    id: 'math',
    name: 'Matemática',
    description: 'Do cálculo básico à álgebra avançada. Domine os números e desbloqueie o título de Mathemagician.',
    icon: 'functions',
    quizCount: 248,
    topics: ['Álgebra Linear', 'Cálculo Diferencial', 'Trigonometria', 'Estatística', 'Geometria'],
    color: 'indigo'
  },
  {
    id: 'bio',
    name: 'Biologia',
    description: 'Explore a ciência da vida, da genética à ecologia. Entenda o mundo ao seu redor.',
    icon: 'biotech',
    quizCount: 156,
    topics: ['Citologia', 'Genética', 'Evolução', 'Ecologia'],
    color: 'emerald'
  },
  {
    id: 'hist',
    name: 'História',
    description: 'Viaje pelo tempo e entenda os eventos que moldaram a humanidade.',
    icon: 'history_edu',
    quizCount: 112,
    topics: ['História Antiga', 'Brasil Colônia', 'Revolução Industrial'],
    color: 'orange'
  },
  {
    id: 'phys',
    name: 'Física',
    description: 'As leis do universo explicadas de forma gamificada.',
    icon: 'rocket_launch',
    quizCount: 184,
    topics: ['Mecânica', 'Termodinâmica', 'Física Quântica'],
    color: 'secondary'
  }
];

export const USER_STATS: UserStats = {
  level: 42,
  xp: 14250,
  xpToNextLevel: 15000,
  streak: 12,
  rank: 142,
  bestCategories: [
    { name: 'CIÊNCIAS EXATAS', percentage: 85 },
    { name: 'CIÊNCIAS HUMANAS', percentage: 62 }
  ]
};

export const ACHIEVEMENTS: Achievement[] = [
  {
    id: '1',
    title: 'Estudioso de Elite',
    description: 'Completou 50 quizzes perfeitos',
    icon: 'emoji_events',
    unlocked: true,
    date: 'Hoje',
    category: 'gold'
  },
  {
    id: '2',
    title: 'Madrugador',
    description: 'Quizzes feitos antes das 7h',
    icon: 'schedule',
    unlocked: true,
    date: '2 dias atrás',
    category: 'silver'
  },
  {
    id: '3',
    title: 'Bibliotecário',
    description: 'Leu 100 artigos recomendados',
    icon: 'menu_book',
    unlocked: true,
    date: '1 semana atrás',
    category: 'bronze'
  }
];

export const MOCK_QUESTIONS: Question[] = [
  // BIOLOGIA
  {
    id: 'q1',
    text: 'Qual é a principal função dos neurotransmissores no sistema nervoso central humano?',
    options: [
      'Regular a temperatura corporal através da homeostase térmica periférica.',
      'Transmitir sinais químicos entre neurônios através das fendas sinápticas.',
      'Produzir energia celular através da síntese de ATP nas mitocôndrias neuronais.',
      'Atuar como barreira física contra patógenos no líquido cefalorraquidiano.'
    ],
    correctOptionIndex: 1,
    explanation: 'Os neurotransmissores são mensageiros químicos que transmitem sinais através das sinapses, permitindo a comunicação entre os neurônios.',
    difficulty: 'médio',
    category: 'Biologia'
  },
  {
    id: 'bio-2',
    text: 'Qual organela celular é responsável pela respiração celular e produção de ATP?',
    options: ['Lisossomo', 'Complexo de Golgi', 'Mitocôndria', 'Ribossomo'],
    correctOptionIndex: 2,
    explanation: 'As mitocôndrias são as "usinas de energia" da célula, convertendo nutrientes em ATP.',
    difficulty: 'fácil',
    category: 'Biologia'
  },
  {
    id: 'bio-3',
    text: 'A base nitrogenada que é exclusiva do RNA (não presente no DNA) é:',
    options: ['Adenina', 'Timina', 'Uracila', 'Citosina'],
    correctOptionIndex: 2,
    explanation: 'O RNA possui Uracila em vez de Timina, que é encontrada apenas no DNA.',
    difficulty: 'médio',
    category: 'Biologia'
  },
  {
    id: 'bio-4',
    text: 'O processo de divisão celular que resulta em quatro células-filhas haploides é a:',
    options: ['Mitose', 'Meiose', 'Bipartição', 'Gemulação'],
    correctOptionIndex: 1,
    explanation: 'A meiose reduz o número de cromossomos pela metade, gerando gametas.',
    difficulty: 'médio',
    category: 'Biologia'
  },
  {
    id: 'bio-5',
    text: 'Quem é considerado o pai da genética moderna por seus estudos com ervilhas?',
    options: ['Charles Darwin', 'Gregor Mendel', 'Louis Pasteur', 'Jean-Baptiste Lamarck'],
    correctOptionIndex: 1,
    explanation: 'Gregor Mendel estabeleceu as leis da hereditariedade através de seus experimentos.',
    difficulty: 'fácil',
    category: 'Biologia'
  },
  
  // FÍSICA
  {
    id: 'q2',
    text: 'Qual a relação entre a constante de Planck e a energia de um fóton segundo a teoria de Einstein?',
    options: [
      'E = h / f',
      'E = h * f',
      'E = f / h',
      'E = h + f'
    ],
    correctOptionIndex: 1,
    explanation: 'A energia de um fóton é diretamente proporcional à sua frequência (f), com a constante de Planck (h) como fator de proporcionalidade.',
    difficulty: 'difícil',
    category: 'Física'
  },
  {
    id: 'phys-2',
    text: 'Qual é a unidade de medida da força no Sistema Internacional (SI)?',
    options: ['Joule', 'Pascal', 'Newton', 'Watt'],
    correctOptionIndex: 2,
    explanation: 'O Newton (N) é a unidade fundamental de força no SI.',
    difficulty: 'fácil',
    category: 'Física'
  },
  {
    id: 'phys-3',
    text: 'Segundo a Primeira Lei de Newton, um objeto em repouso tende a:',
    options: [
      'Entrar em movimento espontâneo.',
      'Permanecer em repouso a menos que uma força externa atue sobre ele.',
      'Aumentar sua massa gradualmente.',
      'Diminuir sua inércia.'
    ],
    correctOptionIndex: 1,
    explanation: 'A Lei da Inércia afirma que estados de movimento só mudam sob ação de forças resultantes não nulas.',
    difficulty: 'fácil',
    category: 'Física'
  },
  {
    id: 'phys-4',
    text: 'A velocidade da luz no vácuo é aproximadamente:',
    options: ['300.000 km/s', '30.000 km/s', '3.000.000 km/s', '3.000 km/s'],
    correctOptionIndex: 0,
    explanation: 'A luz viaja a cerca de 300.000 quilômetros por segundo no vácuo.',
    difficulty: 'médio',
    category: 'Física'
  },
  {
    id: 'phys-5',
    text: 'Qual fenômeno explica por que um remo parece "quebrado" quando mergulhado na água?',
    options: ['Reflexão', 'Refração', 'Difração', 'Interferência'],
    correctOptionIndex: 1,
    explanation: 'A refração ocorre quando a luz muda de velocidade ao passar de um meio para outro (ar para água).',
    difficulty: 'médio',
    category: 'Física'
  },

  // MATEMÁTICA
  {
    id: 'math-1',
    text: 'Qual é o valor da raiz quadrada de 144?',
    options: ['10', '12', '14', '16'],
    correctOptionIndex: 1,
    explanation: '12 multiplicado por 12 é igual a 144.',
    difficulty: 'fácil',
    category: 'Matemática'
  },
  {
    id: 'math-2',
    text: 'Em um triângulo retângulo, o quadrado da hipotenusa é igual à soma dos quadrados dos catetos. Este é o teorema de:',
    options: ['Tales', 'Pitágoras', 'Baskhara', 'Euclides'],
    correctOptionIndex: 1,
    explanation: 'O Teorema de Pitágoras é fundamental na geometria euclidiana.',
    difficulty: 'fácil',
    category: 'Matemática'
  },
  {
    id: 'math-3',
    text: 'Qual é o valor de x na equação 2x + 10 = 20?',
    options: ['5', '10', '15', '20'],
    correctOptionIndex: 0,
    explanation: 'Subtraindo 10 de ambos os lados temos 2x = 10, logo x = 5.',
    difficulty: 'fácil',
    category: 'Matemática'
  },
  {
    id: 'math-4',
    text: 'O que representa a derivada de uma função em um ponto?',
    options: [
      'A área sob a curva.',
      'O valor máximo da função.',
      'A inclinação da reta tangente à curva naquele ponto.',
      'A intersecção com o eixo x.'
    ],
    correctOptionIndex: 2,
    explanation: 'A derivada mede a taxa de variação instantânea de uma função.',
    difficulty: 'médio',
    category: 'Matemática'
  },
  {
    id: 'math-5',
    text: 'Qual é o logaritmo de 1000 na base 10?',
    options: ['1', '2', '3', '10'],
    correctOptionIndex: 2,
    explanation: '10 elevado a 3 é igual a 1000.',
    difficulty: 'médio',
    category: 'Matemática'
  },

  // HISTÓRIA
  {
    id: 'hist-1',
    text: 'Em que ano ocorreu o Descobrimento do Brasil pelos portugueses?',
    options: ['1492', '1500', '1522', '1822'],
    correctOptionIndex: 1,
    explanation: 'Pedro Álvares Cabral chegou ao Brasil em 22 de abril de 1500.',
    difficulty: 'fácil',
    category: 'História'
  },
  {
    id: 'hist-2',
    text: 'Qual foi o principal conflito mundial que durou de 1939 a 1945?',
    options: ['Primeira Guerra Mundial', 'Guerra Fria', 'Segunda Guerra Mundial', 'Guerra do Vietnã'],
    correctOptionIndex: 2,
    explanation: 'A Segunda Guerra Mundial envolveu a maioria das nações do mundo e as grandes potências.',
    difficulty: 'fácil',
    category: 'História'
  },
  {
    id: 'hist-3',
    text: 'Quem foi o primeiro imperador do Brasil?',
    options: ['Dom Pedro I', 'Dom Pedro II', 'Deodoro da Fonseca', 'Getúlio Vargas'],
    correctOptionIndex: 0,
    explanation: 'Dom Pedro I proclamou a independência e tornou-se imperador em 1822.',
    difficulty: 'fácil',
    category: 'História'
  },
  {
    id: 'hist-4',
    text: 'O regime político que vigorou na França até a Revolução de 1789 era conhecido como:',
    options: ['Antigo Regime', 'Renascimento', 'Iluminismo', 'Feudalismo'],
    correctOptionIndex: 0,
    explanation: 'O Antigo Regime era caracterizado pelo absolutismo monárquico.',
    difficulty: 'médio',
    category: 'História'
  },
  {
    id: 'hist-5',
    text: 'A Queda do Muro de Berlim em 1989 simbolizou o fim de qual período?',
    options: ['Guerra Civil Americana', 'Guerra Fria', 'Era Napoleônica', 'Império Romano'],
    correctOptionIndex: 1,
    explanation: 'A queda do muro marcou o início do colapso dos regimes comunistas na Europa.',
    difficulty: 'médio',
    category: 'História'
  }
];
