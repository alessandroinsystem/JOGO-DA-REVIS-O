import React from 'react';
import { motion } from 'motion/react';
import { Zap, TrendingUp, Trophy, Star, ChevronRight, Activity } from 'lucide-react';
import { SUBJECTS, ACHIEVEMENTS } from '../constants';
import { cn } from '@/lib/utils';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';

export function Dashboard() {
  const { userData } = useAuth();
  const navigate = useNavigate();
  const userName = userData?.displayName || 'Estudante';
  const level = userData?.level || 1;
  const xp = userData?.xp || 0;
  const streak = userData?.streak || 0;
  const rank = userData?.rank || 999;
  const xpToNextLevel = level * 1000; // Simplified formula

  const [backendStatus, setBackendStatus] = React.useState<string | null>(null);

  const checkBackend = async () => {
    try {
      const res = await fetch('/api/status');
      const data = await res.json();
      setBackendStatus(data.message);
    } catch {
      setBackendStatus('Erro ao conectar ao Node.js');
    }
  };

  return (
    <div className="space-y-12 pb-20">
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <span className="text-[10px] text-primary font-bold uppercase tracking-[0.3em]">Protocolo de Performance</span>
          <h1 className="font-sans text-4xl font-light text-on-surface mt-2">Bem-vindo, <span className="font-semibold">{userName}</span></h1>
        </div>
        <div className="flex flex-col items-end gap-2">
          <div className="flex items-center gap-3 bg-white/5 border border-outline px-4 py-2 rounded">
            <Activity size={16} className="text-emerald-400" />
            <span className="text-[10px] uppercase tracking-widest text-on-surface-variant">Sessão Ativa: 12:04:22</span>
          </div>
          <button 
            onClick={checkBackend}
            className="text-[9px] uppercase tracking-widest text-primary/60 hover:text-primary transition-colors flex items-center gap-2"
          >
            {backendStatus || "Testar Backend Node.js"}
          </button>
        </div>
      </header>

      {/* Hero Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <motion.div 
          initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
          className="md:col-span-2 technical-card rounded-lg p-8 flex flex-col justify-between min-h-[180px]"
        >
          <div className="flex justify-between items-start mb-6">
            <div className="space-y-1">
              <p className="text-[10px] text-primary uppercase tracking-[0.2em] font-bold">Maturação Acadêmica</p>
              <h2 className="text-3xl font-light tracking-tight">Nível <span className="font-mono text-emerald-400">{level}</span></h2>
            </div>
            <div className="w-10 h-10 border border-primary/20 rounded-full flex items-center justify-center text-primary">
              <Star size={20} fill="currentColor" className="opacity-80" />
            </div>
          </div>
          
          <div className="space-y-3">
            <div className="flex justify-between items-end text-[10px] uppercase tracking-widest font-bold">
              <span className="text-on-surface-variant">Progressão // {xp} XP</span>
              <span className="text-emerald-400">{Math.round((xp / xpToNextLevel) * 100)}% Comp</span>
            </div>
            <div className="w-full h-1.5 bg-white/5 rounded-full overflow-hidden">
              <div 
                className="h-full bg-emerald-500 transition-all duration-1000"
                style={{ width: `${(xp / xpToNextLevel) * 100}%` }}
              />
            </div>
          </div>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
          className="bg-secondary rounded-lg p-8 text-on-secondary flex flex-col justify-between shadow-lg shadow-secondary/10"
        >
          <div className="flex justify-between items-center">
            <Zap size={28} />
            <span className="text-[9px] font-bold tracking-[0.2em] uppercase border border-white/20 px-2 py-1 rounded">Streak</span>
          </div>
          <div>
            <p className="text-5xl font-mono font-bold leading-none">{streak}</p>
            <p className="text-[10px] uppercase tracking-widest font-bold opacity-80 mt-2">Dias Consecutivos</p>
          </div>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}
          className="technical-card rounded-lg p-8 flex flex-col items-center justify-center text-center"
        >
          <div className="w-14 h-14 border border-outline rounded flex items-center justify-center mb-4">
             <Trophy size={28} className="text-on-surface-variant" />
          </div>
          <p className="font-mono text-lg font-bold text-on-surface">RANK #{rank}</p>
          <p className="text-[10px] uppercase tracking-[0.2em] text-on-surface-variant mt-1">Status: {rank < 500 ? 'Grandmaster' : 'Explorer'}</p>
        </motion.div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
        <div className="lg:col-span-2 space-y-8">
          <div className="flex justify-between items-end border-b border-outline pb-4">
            <h3 className="text-xs uppercase tracking-[0.3em] font-bold text-on-surface-variant">Módulos Recomendados</h3>
            <button className="text-primary text-[10px] uppercase tracking-widest font-bold flex items-center gap-2 hover:translate-x-1 transition-transform">
              Base de Dados <ChevronRight size={14} />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {SUBJECTS.map((subject, index) => (
              <motion.div
                key={subject.id}
                whileHover={{ y: -2 }}
                onClick={() => navigate(`/quiz/${subject.id}`)}
                className="technical-card rounded p-6 group cursor-pointer"
              >
                <div className="flex justify-between items-start mb-6">
                   <div className="w-10 h-10 border border-outline rounded flex items-center justify-center text-primary group-hover:border-primary/50 transition-colors">
                     <span className="material-symbols-outlined text-xl">{subject.icon}</span>
                   </div>
                   <span className="text-[9px] font-bold uppercase tracking-widest text-on-surface-variant border border-outline px-2 py-0.5 rounded">
                     {subject.quizCount} Exams
                   </span>
                </div>
                <h4 className="text-sm font-semibold uppercase tracking-wider text-on-surface">{subject.name}</h4>
                <p className="text-xs text-on-surface-variant mt-2 leading-relaxed line-clamp-2">{subject.description}</p>
                <div className="mt-6 pt-6 border-t border-outline flex items-center justify-between">
                   <div className="flex gap-2">
                     {subject.topics.slice(0, 1).map(topic => (
                       <span key={topic} className="text-[9px] uppercase tracking-widest font-bold px-2 py-1 bg-white/5 text-on-surface-variant rounded">
                         {topic}
                       </span>
                     ))}
                   </div>
                   <TrendingUp size={14} className="text-primary opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        <div className="space-y-8">
           <h3 className="text-xs uppercase tracking-[0.3em] font-bold text-on-surface-variant border-b border-outline pb-4">Registros de Mérito</h3>
           <div className="space-y-4">
              {ACHIEVEMENTS.map((achievement, index) => (
                <motion.div
                  key={achievement.id}
                  initial={{ opacity: 0, x: 10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.3 + index * 0.1 }}
                  className="flex items-center gap-4 bg-white/5 p-4 rounded border border-outline hover:border-primary/30 transition-colors"
                >
                  <div className={cn(
                    "w-12 h-12 rounded border flex items-center justify-center",
                    achievement.category === 'gold' ? "border-emerald-500/30 text-emerald-400 bg-emerald-500/5" :
                    achievement.category === 'silver' ? "border-slate-500/30 text-slate-400 bg-slate-500/5" :
                    "border-orange-500/30 text-orange-400 bg-orange-500/5"
                  )}>
                    <span className="material-symbols-outlined text-2xl">{achievement.icon}</span>
                  </div>
                  <div className="flex-1">
                    <p className="text-[11px] font-bold uppercase tracking-wider leading-none text-on-surface">{achievement.title}</p>
                    <p className="text-[9px] uppercase tracking-widest text-on-surface-variant mt-1.5">{achievement.description}</p>
                  </div>
                </motion.div>
              ))}
           </div>
           
           <div className="bg-emerald-600/10 border border-emerald-500/20 rounded p-6 relative overflow-hidden group">
              <div className="relative z-10">
                <p className="text-[9px] font-bold uppercase tracking-[0.3em] text-emerald-400 mb-2">Acesso Prioritário</p>
                <h4 className="text-sm font-semibold uppercase tracking-wider text-white">MindLevel Elite</h4>
                <p className="text-xs text-on-surface-variant mt-2 leading-relaxed">Otimize sua taxa de aprendizado em até 2.4x com módulos neurais avançados.</p>
                <button className="mt-5 w-full bg-emerald-500 text-black font-bold py-2 rounded text-[10px] uppercase tracking-widest hover:bg-emerald-400 transition-colors">
                  Atualizar Credenciais
                </button>
              </div>
              <Activity size={120} className="absolute -bottom-8 -right-8 text-emerald-500 opacity-5 group-hover:scale-110 transition-transform" />
           </div>
        </div>
      </div>
    </div>
  );
}
