import React from 'react';
import { motion } from 'motion/react';
import { Medal, Trophy, Star, Zap, Target, Flame, BookOpen, Clock } from 'lucide-react';
import { ACHIEVEMENTS } from '../constants';
import { cn } from '@/lib/utils';
import { useAuth } from '../contexts/AuthContext';

export function AchievementsPage() {
  const { userData } = useAuth();
  const userLevel = userData?.level || 1;
  const userXp = userData?.xp || 0;

  return (
    <div className="space-y-10">
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <span className="text-[10px] text-secondary font-bold uppercase tracking-[0.3em]">Galeria de Honra</span>
          <h1 className="font-sans text-4xl font-light text-on-surface mt-2">Conquistas <span className="font-semibold">Registradas</span></h1>
        </div>
        <div className="flex items-center gap-6">
          <div className="flex flex-col items-end">
            <span className="text-[9px] uppercase tracking-widest text-on-surface-variant font-bold">Total Desbloqueado</span>
            <span className="text-xl font-mono text-secondary">
              {ACHIEVEMENTS.filter(a => a.id === '1' ? userLevel >= 1 : a.id === '2' ? userLevel >= 5 : a.id === '3' ? userXp > 5000 : false).length} / {ACHIEVEMENTS.length}
            </span>
          </div>
          <div className="w-12 h-12 border border-secondary/20 rounded-full flex items-center justify-center text-secondary">
            <Medal size={24} />
          </div>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {ACHIEVEMENTS.map((achievement, idx) => {
          const isUnlocked = achievement.id === '1' ? userLevel >= 1 : 
                            achievement.id === '2' ? userLevel >= 5 : 
                            achievement.id === '3' ? userXp > 5000 : false;
          
          return (
            <motion.div
              key={achievement.id}
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: idx * 0.05 }}
              className={cn(
                "technical-card rounded-lg p-8 flex flex-col gap-6 group relative overflow-hidden",
                isUnlocked ? "border-secondary/30" : "opacity-50 grayscale border-outline"
              )}
            >
              {!isUnlocked && (
                <div className="absolute inset-0 bg-surface/40 backdrop-blur-[2px] flex items-center justify-center z-10">
                  <span className="text-[10px] font-bold uppercase tracking-[0.3em] text-on-surface-variant border border-outline px-4 py-2 rounded bg-surface">Bloqueado</span>
                </div>
              )}
              
              <div className="flex justify-between items-start">
                <div className={cn(
                  "w-16 h-16 rounded border flex items-center justify-center transition-transform group-hover:scale-110",
                  achievement.category === 'gold' ? "border-emerald-500/30 text-emerald-400 bg-emerald-500/5" :
                  achievement.category === 'silver' ? "border-slate-500/30 text-slate-400 bg-slate-500/5" :
                  "border-orange-500/30 text-orange-400 bg-orange-500/5"
                )}>
                  <span className="material-symbols-outlined text-4xl">{achievement.icon}</span>
                </div>
                {isUnlocked && (
                  <div className="text-right">
                    <span className="text-[9px] font-bold uppercase tracking-widest text-on-surface-variant">Conquistado em</span>
                    <p className="text-[10px] font-mono text-secondary mt-1">{achievement.date}</p>
                  </div>
                )}
              </div>

            <div>
              <h3 className="font-bold uppercase tracking-wider text-on-surface group-hover:text-secondary transition-colors">{achievement.title}</h3>
              <p className="text-xs text-on-surface-variant mt-2 leading-relaxed">{achievement.description}</p>
            </div>

            <div className="pt-6 border-t border-outline flex justify-between items-center">
              <div className="flex gap-2">
                <span className="text-[8px] font-bold uppercase tracking-widest px-2 py-0.5 bg-white/5 rounded border border-outline">Rare</span>
                <span className="text-[8px] font-bold uppercase tracking-widest px-2 py-0.5 bg-white/5 rounded border border-outline">Core</span>
              </div>
              <span className={cn(
                "text-[10px] font-mono font-bold",
                achievement.category === 'gold' ? "text-emerald-400" :
                achievement.category === 'silver' ? "text-slate-400" :
                "text-orange-400"
              )}>
                +{achievement.category === 'gold' ? '1000' : achievement.category === 'silver' ? '500' : '250'} XP
              </span>
            </div>
          </motion.div>
        );
      })}

      {/* Coming Soon placeholders */}
        {[1, 2, 3].map((i) => (
          <div key={i} className="technical-card rounded-lg p-8 opacity-20 border-dashed border-2 flex flex-col items-center justify-center text-center gap-4">
             <Star size={40} className="text-on-surface-variant" />
             <div className="space-y-2">
                <div className="h-4 w-32 bg-on-surface-variant rounded mx-auto" />
                <div className="h-3 w-48 bg-on-surface-variant/50 rounded mx-auto" />
             </div>
          </div>
        ))}
      </div>
    </div>
  );
}
