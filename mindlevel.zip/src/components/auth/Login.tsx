import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { supabase, isSupabaseConfigured } from '../../lib/supabase';
import { useAuth } from '../../contexts/AuthContext';
import { GraduationCap, Mail, Lock, Loader2, ArrowRight } from 'lucide-react';
import { motion } from 'motion/react';

export function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();
  const { user, loading: authLoading } = useAuth();

  useEffect(() => {
    if (!authLoading && user) {
      navigate('/');
    }
  }, [user, authLoading, navigate]);

  const handleEmailLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    if (!isSupabaseConfigured) {
      setError('Supabase não está configurado. Por favor, adicione as variáveis de ambiente.');
      setLoading(false);
      return;
    }

    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });
      
      if (error) {
        if (error.message.includes('Email not confirmed')) {
          setError('Email ainda não confirmado. Por favor, verifique sua caixa de entrada.');
        } else {
          setError('Credenciais inválidas. Verifique seu email e senha.');
        }
        throw error;
      }
      
      navigate('/');
    } catch (err: any) {
      console.error('Erro de login:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    setLoading(true);
    try {
      const { error } = await supabase.auth.signInWithOAuth({
        provider: 'google',
        options: {
          redirectTo: window.location.origin
        }
      });
      if (error) throw error;
    } catch (err: any) {
      setError('Erro ao entrar com Google.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-surface flex flex-col items-center justify-center p-6 relative overflow-hidden">
      <div className="absolute inset-0 opacity-5 pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary rounded-full blur-[120px]" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-secondary rounded-full blur-[120px]" />
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md technical-card rounded-lg p-10 relative z-10"
      >
        <div className="flex flex-col items-center mb-10">
          <div className="w-16 h-16 rounded border border-primary/30 bg-primary/10 flex items-center justify-center text-primary mb-6 shadow-[0_0_20px_rgba(var(--primary-rgb),0.1)]">
            <GraduationCap size={32} />
          </div>
          <p className="text-[10px] font-bold uppercase tracking-[0.4em] text-primary mb-2">Acesso Seguro</p>
          <h1 className="text-2xl font-light tracking-tight text-on-surface">MIND<span className="font-bold">LEVEL</span></h1>
        </div>

        {error && (
          <div className="mb-8 p-4 bg-error/10 border border-error/20 rounded text-error text-[11px] font-bold uppercase tracking-wider text-center">
            {error}
          </div>
        )}

        <form onSubmit={handleEmailLogin} className="space-y-6">
          <div className="space-y-2">
            <label className="text-[10px] font-bold text-on-surface-variant uppercase tracking-[0.2em] ml-1">Identificação</label>
            <div className="relative">
              <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-on-surface-variant" size={16} />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full pl-12 pr-4 py-3 bg-white/5 rounded border border-outline focus:border-primary transition-all outline-none text-sm placeholder:text-on-surface-variant/30"
                placeholder="nome@servidor.com"
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-[10px] font-bold text-on-surface-variant uppercase tracking-[0.2em] ml-1">Chave de Acesso</label>
            <div className="relative">
              <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-on-surface-variant" size={16} />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full pl-12 pr-4 py-3 bg-white/5 rounded border border-outline focus:border-primary transition-all outline-none text-sm placeholder:text-on-surface-variant/30"
                placeholder="••••••••"
                required
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-primary hover:bg-primary/90 text-on-primary font-bold py-4 rounded text-[11px] uppercase tracking-[0.2em] transition-all active:scale-95 flex items-center justify-center gap-3 group glow-emerald shadow-lg"
          >
            {loading ? <Loader2 className="animate-spin" size={18} /> : (
              <>
                Sincronizar Credenciais
                <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
              </>
            )}
          </button>
        </form>

        <div className="relative my-10">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-outline opacity-30"></div>
          </div>
          <div className="relative flex justify-center text-[9px] uppercase tracking-[0.3em]">
            <span className="bg-surface-container px-6 text-on-surface-variant font-bold">Alternativas</span>
          </div>
        </div>

        <button
          onClick={handleGoogleLogin}
          disabled={loading}
          className="w-full bg-white/5 hover:bg-white/10 border border-outline text-on-surface font-bold py-3 rounded text-[10px] uppercase tracking-[0.2em] transition-all flex items-center justify-center gap-3 mb-8"
        >
          <img src="https://www.gstatic.com/images/branding/product/1x/gsa_512dp.png" alt="Google" className="w-4 h-4" />
          Protocolo Google
        </button>

        <p className="text-center text-[10px] uppercase tracking-[0.2em] text-on-surface-variant">
          Sem autorização?{' '}
          <Link to="/register" className="text-primary font-bold hover:text-primary/80 transition-colors">
            Gerar credenciais
          </Link>
        </p>
      </motion.div>
    </div>
  );
}
