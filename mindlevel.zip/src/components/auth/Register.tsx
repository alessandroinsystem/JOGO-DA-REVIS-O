import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { supabase, isSupabaseConfigured } from '../../lib/supabase';
import { useAuth } from '../../contexts/AuthContext';
import { GraduationCap, Mail, Lock, User, Loader2, ArrowRight } from 'lucide-react';
import { motion } from 'motion/react';

export function Register() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);
  const navigate = useNavigate();
  const { user, loading: authLoading } = useAuth();

  useEffect(() => {
    if (!authLoading && user) {
      navigate('/');
    }
  }, [user, authLoading, navigate]);

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    console.log('Iniciando registro para:', email);

    if (!isSupabaseConfigured) {
      setError('Supabase não está configurado. Por favor, adicione as variáveis de ambiente.');
      setLoading(false);
      return;
    }

    try {
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            full_name: name,
          }
        }
      });
      
      if (error) {
        console.error('Erro no signup do Supabase:', error);
        throw error;
      }
      
      console.log('Registro realizado com sucesso:', data);
      
      // Se não houver sessão, significa que precisa confirmar email
      if (!data.session) {
        setSuccess(true);
        setLoading(false);
      } else {
        // Se logou direto, vai para a home (o useEffect cuidará disso, mas garantimos aqui)
        navigate('/');
      }
    } catch (err: any) {
      console.error('Falha catastrófica no registro:', err);
      setError(err.message || 'Erro ao criar conta. Tente novamente.');
      setLoading(false);
    }
  };

  if (success) {
    return (
      <div className="min-h-screen bg-surface flex flex-col items-center justify-center p-6 text-center">
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="w-full max-w-md technical-card rounded-lg p-10"
        >
          <div className="w-16 h-16 rounded border border-secondary/30 bg-secondary/10 flex items-center justify-center text-secondary mx-auto mb-6">
            <Mail size={32} />
          </div>
          <h2 className="text-xl font-bold text-on-surface mb-4 uppercase tracking-tighter">Verificação Necessária</h2>
          <p className="text-sm text-on-surface-variant mb-8">
            Enviamos um código de acesso para <span className="text-secondary font-bold">{email}</span>. 
            Por favor, verifique sua caixa de entrada para ativar seu perfil.
          </p>
          <Link 
            to="/login" 
            className="inline-block w-full bg-secondary text-on-secondary font-bold py-4 rounded text-[11px] uppercase tracking-[0.2em]"
          >
            Ir para Login
          </Link>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-surface flex flex-col items-center justify-center p-6 relative overflow-hidden">
      <div className="absolute inset-0 opacity-5 pointer-events-none">
        <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-secondary rounded-full blur-[120px]" />
        <div className="absolute bottom-1/4 left-1/4 w-96 h-96 bg-primary rounded-full blur-[120px]" />
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md technical-card rounded-lg p-10 relative z-10"
      >
        <div className="flex flex-col items-center mb-10">
          <div className="w-16 h-16 rounded border border-secondary/30 bg-secondary/10 flex items-center justify-center text-secondary mb-6 shadow-[0_0_20px_rgba(249,115,22,0.1)]">
            <GraduationCap size={32} />
          </div>
          <p className="text-[10px] font-bold uppercase tracking-[0.4em] text-secondary mb-2">Novo Cadastro</p>
          <h1 className="text-2xl font-light tracking-tight text-on-surface">JOIN THE <span className="font-bold uppercase tracking-tight">Elite</span></h1>
        </div>

        {error && (
          <div className="mb-8 p-4 bg-error/10 border border-error/20 rounded text-error text-[11px] font-bold uppercase tracking-wider text-center">
            {error}
          </div>
        )}

        <form onSubmit={handleRegister} className="space-y-6">
          <div className="space-y-2">
            <label className="text-[10px] font-bold text-on-surface-variant uppercase tracking-[0.2em] ml-1">Assinatura</label>
            <div className="relative">
              <User className="absolute left-4 top-1/2 -translate-y-1/2 text-on-surface-variant" size={16} />
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full pl-12 pr-4 py-3 bg-white/5 rounded border border-outline focus:border-secondary transition-all outline-none text-sm placeholder:text-on-surface-variant/30"
                placeholder="NOME_CANDIDATO"
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-[10px] font-bold text-on-surface-variant uppercase tracking-[0.2em] ml-1">Canal de Comunicação</label>
            <div className="relative">
              <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-on-surface-variant" size={16} />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full pl-12 pr-4 py-3 bg-white/5 rounded border border-outline focus:border-secondary transition-all outline-none text-sm placeholder:text-on-surface-variant/30"
                placeholder="nome@servidor.com"
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-[10px] font-bold text-on-surface-variant uppercase tracking-[0.2em] ml-1">Código Encriptado</label>
            <div className="relative">
              <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-on-surface-variant" size={16} />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full pl-12 pr-4 py-3 bg-white/5 rounded border border-outline focus:border-secondary transition-all outline-none text-sm placeholder:text-on-surface-variant/30"
                placeholder="MIN_06_CARACTERES"
                required
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-secondary hover:bg-secondary/90 text-on-secondary font-bold py-4 rounded text-[11px] uppercase tracking-[0.2em] transition-all active:scale-95 flex items-center justify-center gap-3 group shadow-lg shadow-secondary/10"
          >
            {loading ? <Loader2 className="animate-spin" size={18} /> : (
              <>
                Inicializar Cadastro
                <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
              </>
            )}
          </button>
        </form>

        <p className="text-center text-[10px] uppercase tracking-[0.2em] text-on-surface-variant mt-10">
          Já possui registro?{' '}
          <Link to="/login" className="text-secondary font-bold hover:text-secondary/80 transition-colors">
            Autenticar agora
          </Link>
        </p>
      </motion.div>
    </div>
  );
}
