import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { LayoutDashboard, BookOpen, Trophy, Medal, Settings, Zap, GraduationCap, LogOut } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useAuth } from '../contexts/AuthContext';

export function Sidebar() {
  const navigate = useNavigate();
  const { userData, logout } = useAuth();
  
  const navItems = [
    { icon: LayoutDashboard, label: 'Dashboard', to: '/' },
    { icon: BookOpen, label: 'Disciplinas', to: '/subjects' },
    { icon: Trophy, label: 'Leaderboard', to: '/leaderboard' },
    { icon: Medal, label: 'Conquistas', to: '/achievements' },
  ];

  return (
    <aside className="hidden md:flex flex-col w-72 h-screen sticky top-0 border-r border-outline bg-surface-container p-6">
      <div className="flex items-center gap-4 mb-10">
        <div className="w-10 h-10 rounded bg-primary flex items-center justify-center text-on-primary font-bold shadow-lg shadow-primary/20">
          <GraduationCap size={24} />
        </div>
        <div className="overflow-hidden">
          <p className="text-[11px] font-bold uppercase tracking-[0.2em] text-on-surface-variant">MindLevel</p>
          <p className="text-sm font-semibold text-on-surface truncate">
            {userData?.displayName || 'Candidato'}
          </p>
        </div>
      </div>

      <nav className="flex-1 space-y-2">
        <p className="text-[10px] uppercase tracking-[0.2em] text-on-surface-variant mb-4 px-4">Menu Principal</p>
        {navItems.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            className={({ isActive }) =>
              cn(
                "flex items-center gap-3 px-4 py-3 rounded border border-transparent transition-all group",
                isActive 
                  ? "bg-primary/10 border-primary/30 text-primary font-medium" 
                  : "text-on-surface-variant hover:bg-white/5 hover:text-on-surface"
              )
            }
          >
            {({ isActive }) => (
              <>
                <item.icon size={18} className={cn("transition-colors", isActive ? "text-primary" : "group-hover:text-on-surface")} />
                <span className="text-xs uppercase tracking-widest">{item.label}</span>
              </>
            )}
          </NavLink>
        ))}
      </nav>

      <div className="pt-6 border-t border-outline space-y-4">
        <div className="p-4 bg-white/5 rounded border border-outline">
          <p className="text-[10px] text-on-surface-variant uppercase tracking-widest mb-1">Status Acadêmico</p>
          <p className="text-xs font-medium text-emerald-400">Level {userData?.level || 1} • Grandmaster</p>
        </div>

        <div className="space-y-1">
          <NavLink
            to="/settings"
            className={({ isActive }) =>
              cn(
                "flex items-center gap-3 px-4 py-2 rounded text-[11px] uppercase tracking-widest transition-all",
                isActive ? "text-primary" : "text-on-surface-variant hover:text-on-surface"
              )
            }
          >
            <Settings size={16} />
            <span>Configurações</span>
          </NavLink>
          
          <button 
            onClick={() => {
              logout();
              navigate('/login');
            }}
            className="flex items-center gap-3 px-4 py-2 rounded text-[11px] uppercase tracking-widest text-on-surface-variant hover:text-error transition-all text-left w-full"
          >
            <LogOut size={16} />
            <span>Encerrar Sessão</span>
          </button>
        </div>
        
        <button 
          onClick={() => navigate('/quiz')}
          className="w-full bg-primary hover:bg-primary/90 text-on-primary font-bold py-3 px-4 rounded text-xs uppercase tracking-[0.2em] transition-all active:scale-95 flex items-center justify-center gap-2 glow-emerald"
        >
          <Zap size={14} fill="currentColor" />
          <span>Daily Examination</span>
        </button>
      </div>
    </aside>
  );
}
