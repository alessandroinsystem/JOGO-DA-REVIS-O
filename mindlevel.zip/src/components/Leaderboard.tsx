import React from 'react';
import { motion } from 'motion/react';
import { Trophy, Medal, Star, ChevronUp, ChevronDown } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useAuth } from '../contexts/AuthContext';

const MOCK_LEADERBOARD = [
  { id: '1', name: 'Alex Rivers', level: 84, xp: 84200, rank: 1, avatar: 'https://i.pravatar.cc/150?u=1' },
  { id: '2', name: 'Sarah Chen', level: 79, xp: 79500, rank: 2, avatar: 'https://i.pravatar.cc/150?u=2' },
  { id: '3', name: 'Marco Vales', level: 75, xp: 75100, rank: 3, avatar: 'https://i.pravatar.cc/150?u=3' },
  { id: '4', name: 'Elena Kostic', level: 68, xp: 68900, rank: 4, avatar: 'https://i.pravatar.cc/150?u=4' },
  { id: '5', name: 'James Wilson', level: 64, xp: 64200, rank: 5, avatar: 'https://i.pravatar.cc/150?u=5' },
  { id: '6', name: 'Sofia Mendez', level: 61, xp: 61000, rank: 6, avatar: 'https://i.pravatar.cc/150?u=6' },
  { id: '7', name: 'Liam O\'Brien', level: 59, xp: 59200, rank: 7, avatar: 'https://i.pravatar.cc/150?u=7' },
];

export function Leaderboard() {
  const { userData } = useAuth();
  
  return (
    <div className="space-y-10">
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <span className="text-[10px] text-primary font-bold uppercase tracking-[0.3em]">Classificação Global</span>
          <h1 className="font-sans text-4xl font-light text-on-surface mt-2">Cúpula de <span className="font-semibold">Performance</span></h1>
        </div>
        <div className="flex items-center gap-4 bg-white/5 border border-outline px-6 py-3 rounded">
          <div className="flex flex-col items-end">
            <span className="text-[9px] uppercase tracking-widest text-on-surface-variant font-bold">Sua Posição</span>
            <span className="text-xl font-mono text-emerald-400">#{userData?.rank || '---'}</span>
          </div>
          <Trophy size={24} className="text-primary" />
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
        {MOCK_LEADERBOARD.slice(0, 3).map((user, idx) => (
          <motion.div
            key={user.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.1 }}
            className={cn(
              "technical-card rounded-lg p-8 flex flex-col items-center text-center relative overflow-hidden",
              idx === 0 ? "border-primary/50 shadow-[0_0_30px_rgba(var(--primary-rgb),0.1)]" : ""
            )}
          >
            {idx === 0 && (
              <div className="absolute top-0 right-0 p-2 bg-primary text-on-primary font-bold text-[10px] uppercase tracking-widest rounded-bl">
                Champion
              </div>
            )}
            <div className="relative mb-6">
              <div className={cn(
                "w-24 h-24 rounded-full border-2 p-1 overflow-hidden",
                idx === 0 ? "border-primary" : idx === 1 ? "border-slate-400" : "border-amber-600"
              )}>
                <img src={user.avatar} alt={user.name} className="w-full h-full rounded-full object-cover" />
              </div>
              <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 bg-surface border border-outline rounded-full px-3 py-1 flex items-center gap-1">
                <span className={cn(
                  "text-xs font-bold",
                  idx === 0 ? "text-primary" : idx === 1 ? "text-slate-400" : "text-amber-600"
                )}>#{user.rank}</span>
              </div>
            </div>
            <h3 className="font-bold text-lg uppercase tracking-wider">{user.name}</h3>
            <p className="text-[10px] uppercase tracking-[0.2em] text-on-surface-variant mt-1">Level {user.level}</p>
            <div className="mt-6 pt-6 border-t border-outline w-full">
              <span className="font-mono text-primary font-bold">{user.xp.toLocaleString()} XP</span>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="technical-card rounded-lg overflow-hidden">
        <div className="p-6 border-b border-outline bg-white/5 grid grid-cols-12 gap-4 text-[10px] uppercase tracking-[0.2em] font-bold text-on-surface-variant">
          <div className="col-span-1 text-center">Pos</div>
          <div className="col-span-6 md:col-span-7">Especialista</div>
          <div className="col-span-2 text-center md:block hidden">Level</div>
          <div className="col-span-3 md:col-span-2 text-right">Pontuação</div>
        </div>
        <div className="divide-y divide-outline">
          {MOCK_LEADERBOARD.map((user) => (
            <div key={user.id} className="p-4 grid grid-cols-12 gap-4 items-center hover:bg-white/5 transition-colors group">
              <div className="col-span-1 text-center font-mono text-sm font-bold text-on-surface-variant group-hover:text-primary">
                {user.rank.toString().padStart(2, '0')}
              </div>
              <div className="col-span-6 md:col-span-7 flex items-center gap-4">
                <div className="w-10 h-10 rounded-full border border-outline overflow-hidden hidden sm:block">
                  <img src={user.avatar} alt={user.name} className="w-full h-full object-cover" />
                </div>
                <div>
                  <p className="text-sm font-semibold uppercase tracking-wider text-on-surface">{user.name}</p>
                  <p className="text-[9px] uppercase tracking-widest text-on-surface-variant sm:hidden">LVL {user.level}</p>
                </div>
              </div>
              <div className="col-span-2 text-center font-mono text-sm text-on-surface-variant hidden md:block">
                {user.level}
              </div>
              <div className="col-span-3 md:col-span-2 text-right font-mono text-sm font-bold text-emerald-400">
                {user.xp.toLocaleString()}
              </div>
            </div>
          ))}
          {userData && !MOCK_LEADERBOARD.find(u => u.id === userData.userId) && (
            <div className="p-4 grid grid-cols-12 gap-4 items-center bg-primary/5 border-l-2 border-primary">
              <div className="col-span-1 text-center font-mono text-sm font-bold text-primary">
                {userData.rank || '---'}
              </div>
              <div className="col-span-6 md:col-span-7 flex items-center gap-4">
                <div className="w-10 h-10 rounded-full border border-primary/30 overflow-hidden hidden sm:block bg-primary/10 flex items-center justify-center">
                  <span className="text-xs font-bold text-primary">{userData.displayName?.[0] || 'U'}</span>
                </div>
                <div>
                  <p className="text-sm font-semibold uppercase tracking-wider text-on-surface">{userData.displayName} (Você)</p>
                  <p className="text-[9px] uppercase tracking-widest text-on-surface-variant sm:hidden">LVL {userData.level}</p>
                </div>
              </div>
              <div className="col-span-2 text-center font-mono text-sm text-on-surface-variant hidden md:block">
                {userData.level}
              </div>
              <div className="col-span-3 md:col-span-2 text-right font-mono text-sm font-bold text-emerald-400">
                {(userData.xp || 0).toLocaleString()}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
