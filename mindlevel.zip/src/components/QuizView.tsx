import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Timer, Lightbulb, ChevronRight, CheckCircle2, AlertCircle } from 'lucide-react';
import { MOCK_QUESTIONS } from '../constants';
import { Question } from '../types';
import { cn } from '@/lib/utils';

interface QuizViewProps {
  onComplete: (score: number) => void;
  onQuestionsLoad?: (count: number) => void;
  subjectId?: string;
}

export function QuizView({ onComplete, onQuestionsLoad, subjectId }: QuizViewProps) {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isConfirmed, setIsConfirmed] = useState(false);
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(30);

  // Filter questions by subject if subjectId is provided
  const questions = React.useMemo(() => {
    if (!subjectId) return MOCK_QUESTIONS;
    
    // Map subjectId to category name
    const subjectMap: Record<string, string> = {
      'math': 'Matemática',
      'bio': 'Biologia',
      'hist': 'História',
      'phys': 'Física'
    };
    
    const categoryName = subjectMap[subjectId];
    const filtered = MOCK_QUESTIONS.filter(q => q.category === categoryName);
    
    // If no specific questions, return some mock ones tagged as that category
    let result = filtered;
    if (filtered.length === 0) {
      result = MOCK_QUESTIONS.slice(0, 5).map((q, idx) => ({
        ...q,
        id: `${subjectId}-q${idx}`,
        category: categoryName || 'Geral'
      }));
    }
    
    return result;
  }, [subjectId]);

  useEffect(() => {
    if (onQuestionsLoad) {
      onQuestionsLoad(questions.length);
    }
  }, [questions.length, onQuestionsLoad]);

  const question = questions[currentQuestionIndex];

  useEffect(() => {
    if (isConfirmed) return;
    
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [currentQuestionIndex, isConfirmed]);

  const handleOptionSelect = (index: number) => {
    if (isConfirmed) return;
    setSelectedOption(index);
  };

  const handleConfirm = () => {
    if (selectedOption === null) return;
    setIsConfirmed(true);
    if (selectedOption === question.correctOptionIndex) {
      setScore(prev => prev + 1);
    }
  };

  const handleNext = () => {
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
      setSelectedOption(null);
      setIsConfirmed(false);
      setTimeLeft(30);
    } else {
      onComplete(score);
    }
  };

  return (
    <div className="max-w-4xl mx-auto py-12 px-6 min-h-[calc(100vh-120px)] flex flex-col">
      <div className="flex justify-between items-end mb-8 border-b border-outline pb-6">
        <div className="space-y-1">
          <p className="text-[10px] text-primary font-bold uppercase tracking-[0.3em]">Ambiente de Exame</p>
          <h2 className="text-xl font-light text-on-surface">Módulo: {question?.category || 'Geral'}</h2>
        </div>
        <div className="flex flex-col items-end gap-1">
          <div className="flex items-center gap-3 px-4 py-2 bg-white/5 border border-outline rounded font-mono text-sm text-primary">
            <Timer size={16} />
            <span>{Math.floor(timeLeft / 60)}:{String(timeLeft % 60).padStart(2, '0')}</span>
          </div>
          <span className="text-[9px] uppercase tracking-widest text-on-surface-variant font-bold">Tempo Restante</span>
        </div>
      </div>

      <div className="w-full h-1 bg-white/5 rounded-full overflow-hidden mb-16">
        <div 
          className="h-full bg-emerald-500 transition-all duration-500"
          style={{ width: `${((currentQuestionIndex + 1) / questions.length) * 100}%` }}
        />
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={question?.id}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          className="space-y-10 flex-1"
        >
          <div className="space-y-4">
            <span className="text-[11px] font-bold uppercase tracking-[0.2em] text-on-surface-variant">Questão {currentQuestionIndex + 1} de {questions.length}</span>
            <h3 className="text-2xl font-semibold leading-relaxed text-on-surface">
              {question?.text}
            </h3>
          </div>

          <div className="grid grid-cols-1 gap-3">
            {question?.options.map((option, index) => {
              const isSelected = selectedOption === index;
              const isCorrect = isConfirmed && index === question.correctOptionIndex;
              const isWrong = isConfirmed && isSelected && index !== question.correctOptionIndex;

              return (
                <button
                  key={index}
                  onClick={() => handleOptionSelect(index)}
                  disabled={isConfirmed}
                  className={cn(
                    "flex items-center gap-6 p-6 rounded border transition-all text-left relative group overflow-hidden",
                    !isConfirmed && isSelected && "border-primary bg-primary/10",
                    !isConfirmed && !isSelected && "border-outline bg-white/5 hover:border-primary/50 hover:bg-white/10",
                    isConfirmed && isCorrect && "border-emerald-500 bg-emerald-500/10 shadow-[0_0_20px_rgba(16,185,129,0.1)]",
                    isConfirmed && isWrong && "border-error bg-error/10 shadow-[0_0_20px_rgba(239,68,68,0.1)]",
                    isConfirmed && !isCorrect && !isWrong && "opacity-40 grayscale border-outline"
                  )}
                >
                  <div className={cn(
                    "w-8 h-8 rounded border flex items-center justify-center text-[11px] font-bold tracking-widest transition-all shrink-0",
                    !isConfirmed && isSelected && "border-primary text-primary bg-primary/20",
                    !isConfirmed && !isSelected && "border-outline text-on-surface-variant group-hover:border-primary group-hover:text-primary",
                    isConfirmed && isCorrect && "border-emerald-500 text-emerald-400 bg-emerald-500/20",
                    isConfirmed && isWrong && "border-error text-error bg-error/20",
                    isConfirmed && !isCorrect && !isWrong && "border-outline text-on-surface-variant"
                  )}>
                    {String.fromCharCode(65 + index)}
                  </div>
                  <p className="flex-1 text-sm font-medium text-on-surface group-hover:text-white transition-colors">{option}</p>
                  {isConfirmed && isCorrect && <CheckCircle2 className="text-emerald-500 shrink-0" size={20} />}
                  {isConfirmed && isWrong && <AlertCircle className="text-error shrink-0" size={20} />}
                </button>
              );
            })}
          </div>

          {isConfirmed && question && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="p-8 bg-white/5 rounded border border-outline border-l-4 border-l-primary"
            >
              <div className="flex items-start gap-4">
                <div className="p-2 border border-primary/20 rounded bg-primary/10">
                  <Lightbulb className="text-primary" size={20} />
                </div>
                <div>
                  <h4 className="text-[11px] font-bold uppercase tracking-[0.2em] text-primary">Análise Pedagógica</h4>
                  <p className="text-sm text-on-surface-variant mt-2 leading-relaxed">
                    {question.explanation}
                  </p>
                </div>
              </div>
            </motion.div>
          )}
        </motion.div>
      </AnimatePresence>

      <div className="mt-16 flex items-center justify-between pt-10 border-t border-outline">
        <div className="flex gap-6">
          <button className="flex items-center gap-3 text-[10px] uppercase tracking-widest font-bold text-on-surface-variant hover:text-primary transition-colors">
            <Lightbulb size={16} />
            <span>Solicitar Dica</span>
          </button>
          {!isConfirmed && (
             <button className="text-[10px] uppercase tracking-widest font-bold text-on-surface-variant hover:text-on-surface transition-colors">
               Saltar Desafio
             </button>
          )}
        </div>

        {!isConfirmed ? (
          <button
            onClick={handleConfirm}
            disabled={selectedOption === null}
            className="px-12 py-3 bg-primary disabled:opacity-50 text-on-primary text-[11px] uppercase tracking-[0.2em] font-bold rounded transition-all active:scale-95 disabled:scale-100 glow-emerald"
          >
            Submeter Resposta
          </button>
        ) : (
          <button
            onClick={handleNext}
            className="px-12 py-3 bg-primary text-on-primary text-[11px] uppercase tracking-[0.2em] font-bold rounded transition-all active:scale-95 flex items-center gap-3 group glow-emerald"
          >
            {currentQuestionIndex < questions.length - 1 ? 'Prosseguir' : 'Finalizar Exame'}
            <ChevronRight size={16} className="group-hover:translate-x-1 transition-transform" />
          </button>
        )}
      </div>
    </div>
  );
}
