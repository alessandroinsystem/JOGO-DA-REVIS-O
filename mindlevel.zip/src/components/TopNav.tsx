import React from 'react';
import { Search, Bell, Crown } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

export function TopNav() {
  const { user, userData } = useAuth();
  const photoURL = user?.photoURL || userData?.photoURL || "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?q=80&w=150&auto=format&fit=crop";

  return (
    <header className="sticky top-0 z-50 w-full bg-surface-container/80 backdrop-blur-md border-b border-outline px-8 py-4">
      <div className="flex justify-between items-center max-w-7xl mx-auto">
        <div className="flex items-center gap-6">
          <div className="md:hidden flex items-center gap-2">
             <div className="w-6 h-6 bg-primary rounded flex items-center justify-center text-on-primary font-bold text-xs uppercase">Σ</div>
          </div>
          
          <div className="hidden sm:flex items-center bg-white/5 rounded border border-outline px-4 py-2">
            <Search className="text-on-surface-variant w-4 h-4" />
            <input 
              type="text" 
              placeholder="PESQUISAR MÓDULOS..." 
              className="bg-transparent border-none focus:ring-0 text-[10px] uppercase tracking-widest text-on-surface ml-3 w-48 md:w-64 placeholder:text-on-surface-variant/50"
            />
          </div>
        </div>

        <div className="flex items-center gap-6">
          <div className="hidden lg:flex flex-col items-end border-r border-outline pr-6 mr-2">
            <span className="text-[9px] text-on-surface-variant uppercase tracking-[0.2em]">Conectividade</span>
            <span className="text-[11px] text-emerald-400 font-mono">ESTÁVEL // 042ms</span>
          </div>

          <div className="flex items-center gap-3">
            <button className="p-2 text-on-surface-variant hover:text-on-surface transition-colors">
              <Bell size={18} />
            </button>
            <button className="p-2 text-primary hover:text-primary-light transition-colors">
              <Crown size={18} />
            </button>
            <div className="h-8 w-8 rounded border border-primary/50 overflow-hidden ml-2 shadow-sm">
               <img 
                src={photoURL} 
                alt="User" 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
