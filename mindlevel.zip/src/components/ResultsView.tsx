import React from 'react';
import { motion } from 'motion/react';
import { Trophy, ArrowLeft, RotateCcw, Share2, Medal, ChevronRight } from 'lucide-react';
import { MOCK_QUESTIONS } from '../constants';

interface ResultsViewProps {
  score: number;
  totalQuestions: number;
  onReset: () => void;
}

export function ResultsView({ score, totalQuestions, onReset }: ResultsViewProps) {
  const percentage = (score / totalQuestions) * 100;
  
  return (
    <div className="max-w-4xl mx-auto py-12 px-6">
      <motion.section 
        initial={{ opacity: 0, scale: 0.98 }}
        animate={{ opacity: 1, scale: 1 }}
        className="relative mb-12 rounded overflow-hidden p-12 bg-white/5 border border-outline text-on-surface"
      >
        <div className="absolute top-0 right-0 p-8 opacity-10">
          <Medal size={200} />
        </div>
        
        <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-12">
          <div className="text-center md:text-left space-y-4">
            <span className="inline-block px-3 py-1 border border-primary/30 bg-primary/10 text-primary text-[10px] font-bold uppercase tracking-[0.3em] mb-2 rounded">
              Desempenho de Cúpula
            </span>
            <h1 className="text-4xl font-light tracking-tight">Avaliação <span className="font-semibold">Finalizada</span></h1>
            <p className="text-on-surface-variant max-w-lg text-sm leading-relaxed">
              Os dados foram processados. Sua precisão analítica atingiu níveis de conformidade superiores ao padrão esperado para este módulo.
            </p>
          </div>
          <div className="flex flex-col items-center gap-6 group">
            <div className="w-40 h-40 rounded-full border border-primary/20 flex items-center justify-center relative shadow-[0_0_40px_rgba(var(--primary-rgb),0.05)] transition-transform group-hover:scale-105">
              <Medal className="text-primary" size={60} />
              <div className="absolute inset-0 border-2 border-primary/10 border-dashed rounded-full animate-[spin_20s_linear_infinite]" />
            </div>
            <div className="text-center space-y-1">
              <span className="font-mono text-3xl font-bold text-emerald-400">+1.250 XP</span>
              <p className="text-[10px] uppercase tracking-widest text-on-surface-variant">Bônus de Eficiência</p>
            </div>
          </div>
        </div>
      </motion.section>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
        <div className="technical-card rounded p-10 flex flex-col items-center justify-center text-center">
           <span className="text-[10px] font-bold text-on-surface-variant uppercase tracking-[0.2em] mb-8">Taxa de Conversão</span>
           <div className="relative w-48 h-48 flex items-center justify-center">
              <svg className="w-full h-full transform -rotate-90">
                <circle className="text-white/5" cx="96" cy="96" fill="transparent" r="80" stroke="currentColor" strokeWidth="6" />
                <circle 
                  className="text-primary opacity-80" 
                  cx="96" cy="96" fill="transparent" r="80" 
                  stroke="currentColor" 
                  strokeWidth="6"
                  strokeDasharray="502"
                  strokeDashoffset={502 * (1 - percentage / 100)}
                  strokeLinecap="square"
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="font-mono text-5xl font-bold text-on-surface">{score}<span className="text-on-surface-variant text-2xl">/{totalQuestions}</span></span>
                <span className="text-[9px] uppercase tracking-widest text-on-surface-variant mt-2 font-bold">Acertos Totais</span>
              </div>
           </div>
           
           <div className="mt-10 grid grid-cols-2 gap-6 w-full">
             <div className="p-4 bg-white/5 border border-outline rounded">
                <p className="text-[9px] text-on-surface-variant uppercase tracking-widest font-bold mb-1.5">Latência</p>
                <p className="font-mono font-bold text-primary text-lg">08:42s</p>
             </div>
             <div className="p-4 bg-white/5 border border-outline rounded">
                <p className="text-[9px] text-on-surface-variant uppercase tracking-widest font-bold mb-1.5">Eficiência</p>
                <p className="font-mono font-bold text-emerald-400 text-lg">{percentage}%</p>
             </div>
           </div>
        </div>

        <div className="technical-card rounded p-10">
          <h3 className="text-xs uppercase tracking-[0.3em] font-bold text-on-surface-variant mb-10 pb-4 border-b border-outline flex items-center gap-3">
            <Trophy className="text-primary" size={16} />
            Mapeamento Cognitivo
          </h3>
          <div className="space-y-8">
            <div className="space-y-3">
               <div className="flex justify-between text-[10px] uppercase tracking-widest font-bold">
                  <span className="text-on-surface">Algoritmos de IA</span>
                  <span className="text-emerald-400">100%</span>
               </div>
               <div className="h-1 w-full bg-white/5 rounded-full overflow-hidden">
                  <div className="h-full bg-emerald-500 w-full" />
               </div>
            </div>
            <div className="space-y-3">
               <div className="flex justify-between text-[10px] uppercase tracking-widest font-bold">
                  <span className="text-on-surface">Redes Neurais</span>
                  <span className="text-orange-400">50%</span>
               </div>
               <div className="h-1 w-full bg-white/5 rounded-full overflow-hidden">
                  <div className="h-full bg-orange-500 w-1/2" />
               </div>
            </div>
          </div>

          <div className="mt-12 p-6 bg-primary/10 rounded border border-primary/20 flex items-start gap-4">
             <div className="p-2 bg-primary/20 border border-primary/30 rounded text-primary shrink-0">
               <Share2 size={18} />
             </div>
             <div>
                <p className="text-[10px] font-bold uppercase tracking-widest text-primary leading-none">Insight do Sistema</p>
                <p className="text-[11px] text-on-surface-variant mt-2 leading-relaxed">
                  Detectamos instabilidade teórica em "Redes Neurais". Recomendamos recalibragem imediata deste módulo.
                </p>
             </div>
          </div>
        </div>
      </div>

      <div className="flex flex-col md:flex-row gap-6 items-center justify-between py-10 border-t border-outline">
         <button onClick={onReset} className="flex items-center gap-3 text-[10px] uppercase tracking-[0.2em] font-bold text-on-surface-variant hover:text-on-surface transition-colors">
            <ArrowLeft size={18} />
            Retornar ao Hub
         </button>
         
         <div className="flex gap-4">
            <button className="flex items-center gap-3 px-8 py-3 border border-outline text-[10px] uppercase tracking-[0.2em] font-bold text-on-surface rounded hover:bg-white/5 transition-all">
              <RotateCcw size={16} />
              Rearquivar Exame
            </button>
            <button className="flex items-center gap-3 px-10 py-3 bg-primary text-on-primary text-[10px] uppercase tracking-[0.2em] font-bold rounded transition-all glow-emerald hover:brightness-110">
              Próxima Fase
              <ChevronRight size={16} />
            </button>
         </div>
      </div>
    </div>
  );
}
