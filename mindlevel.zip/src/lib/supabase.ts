import { createClient } from '@supabase/supabase-js';

const rawUrl = (import.meta.env.VITE_SUPABASE_URL || '').trim();
const supabaseAnonKey = (import.meta.env.VITE_SUPABASE_ANON_KEY || import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY || '').trim();

// Ensure URL has protocol if provided
export let supabaseUrl = (rawUrl || '').trim();
if (supabaseUrl && !supabaseUrl.startsWith('http')) {
  supabaseUrl = `https://${supabaseUrl}`;
}

// Check if we have reachable credentials
export const isSupabaseConfigured = !!(
  supabaseUrl && 
  supabaseUrl.includes('.') && 
  supabaseAnonKey && 
  supabaseAnonKey.length > 20
);

if (!isSupabaseConfigured) {
  console.warn('Supabase: missing or invalid credentials. Check your .env variables.');
}

export const supabase = createClient(
  supabaseUrl || 'https://placeholder.supabase.co',
  supabaseAnonKey || 'placeholder-key',
  {
    auth: {
      persistSession: true,
      autoRefreshToken: true,
      detectSessionInUrl: true
    },
    global: {
      headers: { 'x-application-name': 'edu-gamified' }
    }
  }
);

// Basic health check to catch "Failed to fetch" early
if (isSupabaseConfigured) {
  fetch(`${supabaseUrl}/rest/v1/`, { 
    method: 'GET', 
    headers: { 'apikey': supabaseAnonKey } 
  }).catch(err => {
    if (err.message.includes('Failed to fetch')) {
      console.error('ERRO DE CONEXÃO SUPABASE: Não foi possível alcançar o servidor Supabase. Verifique se o URL está correto e se o seu projeto Supabase está ativo.');
    }
  });
}
