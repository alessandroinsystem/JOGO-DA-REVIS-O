import React, { createContext, useContext, useEffect, useState } from 'react';
import { User } from '@supabase/supabase-js';
import { supabase, isSupabaseConfigured, supabaseUrl } from '../lib/supabase';

interface AuthContextType {
  user: User | null;
  loading: boolean;
  userData: any | null;
  logout: () => Promise<void>;
  updateUserStats: (xpGain: number) => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  loading: true,
  userData: null,
  logout: async () => {},
  updateUserStats: async () => {},
});

export const useAuth = () => useContext(AuthContext);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [userData, setUserData] = useState<any | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Prevent calls if Supabase is not properly configured
    if (!isSupabaseConfigured) {
      setLoading(false);
      return;
    }

    let isMounted = true;
    
    // Failsafe timeout to prevent infinite loading state (12s)
    const loadingTimeout = setTimeout(() => {
      if (isMounted && loading) {
        console.warn('AUTH TIMEOUT: O sistema não recebeu resposta do Supabase em 12 segundos.');
        console.info('Configuração Supabase:', { 
          configurada: isSupabaseConfigured,
          url: supabaseUrl ? `${supabaseUrl.substring(0, 15)}...` : 'ausente'
        });
        setLoading(false);
      }
    }, 12000);

    const fetchProfile = async (userId: string) => {
      console.log('AUTENTICADO: Buscando perfil para', userId);
      try {
        const { data, error } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', userId)
          .maybeSingle();

        if (isMounted) {
          if (error) {
            console.warn('AVISO DE PERFIL:', error.message);
            setUserData({ id: userId, xp: 0, level: 1, streak: 0 });
          } else {
            console.log('PERFIL CARREGADO:', data || 'Dados padrão');
            setUserData(data || { id: userId, xp: 0, level: 1, streak: 0 });
          }
        }
      } catch (err) {
        console.error('ERRO DE PERFIL:', err);
        if (isMounted) setUserData({ id: userId, xp: 0, level: 1, streak: 0 });
      } finally {
        if (isMounted) setLoading(false);
      }
    };

    // Consolidated auth state handler
    const handleAuthStateChange = async (event: string, session: any) => {
      if (!isMounted) return;
      
      console.log(`AUTH EVENTO: ${event}`, session ? 'Sessão ativa' : 'Sem sessão');
      const currentUser = session?.user ?? null;
      setUser(currentUser);

      if (currentUser) {
        // Try to fetch profile, but don't hold up the app if it fails
        fetchProfile(currentUser.id).catch(err => {
          console.error('ERRO EM fetchProfile:', err);
          if (isMounted) setLoading(false);
        });
      } else {
        setUserData(null);
        setLoading(false);
      }
    };

    console.log('AUTO-CHECK: Iniciando verificação de sessão...');
    // Initial check
    const initAuth = async () => {
      console.log('AUTH INIT: Iniciando processo de autenticação...');
      if (!isSupabaseConfigured) {
        console.error('ERRO: Supabase não configurado. Adicione VITE_SUPABASE_URL e VITE_SUPABASE_ANON_KEY no Vercel.');
        if (isMounted) setLoading(false);
        return;
      }

      try {
        const { data: { session }, error } = await supabase.auth.getSession();
        if (error) {
          console.error('ERRO EM getSession:', error.message);
          throw error;
        }
        await handleAuthStateChange('INITIAL_GET_SESSION', session);
      } catch (err) {
        console.error('FALHA CRÍTICA getSession:', err);
        // Ensure we stop loading even on failure
        if (isMounted) setLoading(false);
      }
    };

    initAuth();

    // Listen for changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      handleAuthStateChange(event, session);
    });

    return () => {
      isMounted = false;
      clearTimeout(loadingTimeout);
      subscription.unsubscribe();
    };
  }, []);

  // Removed old fetchUserData since it's now internal to the effect to ensure stability

  const logout = async () => {
    try {
      await supabase.auth.signOut();
      setUser(null);
      setUserData(null);
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  const updateUserStats = async (xpGain: number) => {
    if (!user || !userData) return;

    const newXp = (userData.xp || 0) + xpGain;
    const currentLevel = userData.level || 1;
    const xpToNextLevel = currentLevel * 1000;
    
    let newLevel = currentLevel;
    let finalXp = newXp;

    if (newXp >= xpToNextLevel) {
      newLevel += 1;
      finalXp = newXp - xpToNextLevel;
    }

    try {
      const { error } = await supabase
        .from('profiles')
        .update({
          xp: finalXp,
          level: newLevel,
          streak: (userData.streak || 0) + 1,
          updated_at: new Date().toISOString(),
        })
        .eq('id', user.id);

      if (error) throw error;
      
      // Update local state
      setUserData(prev => ({
        ...prev,
        xp: finalXp,
        level: newLevel,
        streak: (prev.streak || 0) + 1
      }));
    } catch (error) {
      console.error('Error updating user stats:', error);
    }
  };

  return (
    <AuthContext.Provider value={{ user, loading, userData, logout, updateUserStats }}>
      {children}
    </AuthContext.Provider>
  );
}
