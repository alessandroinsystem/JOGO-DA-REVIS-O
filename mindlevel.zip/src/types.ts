export interface Question {
  id: string;
  text: string;
  options: string[];
  correctOptionIndex: number;
  explanation: string;
  difficulty: 'fácil' | 'médio' | 'difícil';
  category: string;
}

export interface Subject {
  id: string;
  name: string;
  description: string;
  icon: string;
  quizCount: number;
  topics: string[];
  color: string;
}

export interface UserStats {
  level: number;
  xp: number;
  xpToNextLevel: number;
  streak: number;
  rank: number;
  bestCategories: { name: string; percentage: number }[];
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  unlocked: boolean;
  date?: string;
  category: 'gold' | 'silver' | 'bronze';
}
