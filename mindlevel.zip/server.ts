import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Exemplo de rota de API no Node.js
  app.get("/api/status", (req, res) => {
    res.json({ 
      status: "online", 
      message: "Backend Node.js funcionando!",
      timestamp: new Date().toISOString()
    });
  });

  // Configuração do Vite Middleware
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`\x1b[32m[BACKEND]\x1b[0m Servidor rodando em http://localhost:${PORT}`);
    console.log(`\x1b[34m[VITE]\x1b[0m Frontend disponível via middleware`);
  });
}

startServer().catch((err) => {
  console.error("Erro ao iniciar servidor:", err);
  process.exit(1);
});
